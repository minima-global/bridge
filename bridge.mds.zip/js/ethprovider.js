
var INFURA_API_KEY = "05c98544804b478994665892aeff361c";

var NETWORKS = {
    mainnet: `https://mainnet.infura.io/v3/${INFURA_API_KEY}`,
    sepolia: `https://sepolia.infura.io/v3/${INFURA_API_KEY}`,
    hardhat: "http://127.0.0.1:8545"
}

var CURRENT_NETWORK = "sepolia";

// '{"jsonrpc":"2.0","method":"eth_getBalance","params": ["0xc94770007dda54cF92009BFF0dE90c06F603a09f", "latest"],"id":1}'

// Balance of Eth and wMinima
function getEthereumBalance (ofAddress) {
    return new Promise((resolve) => {
        MDS.net.POST(
            NETWORKS[CURRENT_NETWORK],
            JSON.stringify({
                "jsonrpc": "2.0",
                "method": "eth_getBalance",
                "params": [ofAddress, "latest"],
                "id": 1
            }),
            function (resp) {
                const balance = resp.result;
    
                resolve(balance);
            }
        )
    });
}

function getWrappedBalance () {

}

// The ability to check the timelock of an ETH HTLC and to collect it.


// The ability to check for HTLC relevant to me.. so I can send the Minima HTLC.


// The ability to collect an ETH HTLC with a secret.. AND for the other user to also know the secret..

