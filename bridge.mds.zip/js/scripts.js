
var MAIN_ADDRESS = "LET type=[bridge address] RETURN SIGNEDBY(*)";
